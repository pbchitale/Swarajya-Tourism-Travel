// Basic script placeholder
document.addEventListener("DOMContentLoaded", () => {
    console.log("Website loaded successfully!");
});
